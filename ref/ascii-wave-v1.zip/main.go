package main

import (
	"fmt"
	"math"
	"os"
	"strings"
	"time"

	tea "github.com/charmbracelet/bubbletea"
	"github.com/charmbracelet/lipgloss"
)

// ─────────────────────────────────────────────
// Configuration — tweak these to tune the feel
// ─────────────────────────────────────────────

// ASCII density ramp: space → densest
var chars = []rune{' ', '.', ':', '-', '=', '+', '*', '#', '%'}

// Color ramp per density level (dark theme - teal accent)
var colorsTeal = []string{
	"#1e1e2e", // 0: space — invisible against bg
	"#2a2a3e", // 1: dot — barely visible
	"#3a3a50", // 2: colon
	"#4a4a62", // 3: dash
	"#555575", // 4: equals
	"#656588", // 5: plus
	"#7a7a9a", // 6: asterisk
	"#7aa8be", // 7: hash — accent begins
	"#88c0d0", // 8: percent — full accent
}

// Alternative palette: purple/prism theme
var colorsPurple = []string{
	"#1a1a2e",
	"#2a2a42",
	"#3a3a55",
	"#4a4a68",
	"#5a5a7b",
	"#6a6a8e",
	"#7a7aa2",
	"#9a7abc",
	"#b48eda",
}

// Wave source configuration
type waveSource struct {
	cx, cy float64 // focal point (normalized 0-1)
	freq   float64 // wave frequency
	speed  float64 // phase speed multiplier
	amp    float64 // amplitude (0-1)
}

var waveSources = []waveSource{
	{cx: 0.40, cy: 0.30, freq: 38.0, speed: 1.0, amp: 1.0},   // primary — upper-center
	{cx: 0.70, cy: 0.60, freq: 26.0, speed: 1.3, amp: 0.45},  // secondary — offset
	{cx: 0.20, cy: 0.75, freq: 32.0, speed: 0.7, amp: 0.30},  // tertiary — lower-left
}

const (
	tickInterval = 66 * time.Millisecond // ~15 FPS
	phaseStep    = 0.10                  // phase increment per tick
	falloffPower = 0.70                  // how quickly edges fade
	ySquash      = 0.45                  // squash y-axis for elliptical rings (terminal chars are ~2:1)
)

// ─────────────────────────────────────────────
// Model
// ─────────────────────────────────────────────

type model struct {
	width  int
	height int
	phase  float64
	colors []string
	styles []lipgloss.Style
	title  string
}

type tickMsg time.Time

func tickCmd() tea.Cmd {
	return tea.Tick(tickInterval, func(t time.Time) tea.Msg {
		return tickMsg(t)
	})
}

func initialModel() model {
	m := model{
		colors: colorsTeal,
		title:  "Prism",
	}
	m.buildStyles()
	return m
}

func (m *model) buildStyles() {
	m.styles = make([]lipgloss.Style, len(chars))
	for i, c := range m.colors {
		m.styles[i] = lipgloss.NewStyle().Foreground(lipgloss.Color(c))
	}
}

// ─────────────────────────────────────────────
// Bubble Tea interface
// ─────────────────────────────────────────────

func (m model) Init() tea.Cmd {
	return tickCmd()
}

func (m model) Update(msg tea.Msg) (tea.Model, tea.Cmd) {
	switch msg := msg.(type) {

	case tea.KeyMsg:
		switch msg.String() {
		case "q", "esc", "ctrl+c":
			return m, tea.Quit
		case "1":
			m.colors = colorsTeal
			m.buildStyles()
		case "2":
			m.colors = colorsPurple
			m.buildStyles()
		}

	case tea.WindowSizeMsg:
		m.width = msg.Width
		m.height = msg.Height

	case tickMsg:
		m.phase += phaseStep
		return m, tickCmd()
	}

	return m, nil
}

func (m model) View() string {
	if m.width == 0 || m.height == 0 {
		return ""
	}

	var b strings.Builder
	b.Grow(m.width * m.height * 20) // pre-alloc for ANSI sequences

	numChars := len(chars)
	w := float64(m.width)
	h := float64(m.height)

	// Pre-compute constant total amplitude
	totalAmp := 0.0
	for _, src := range waveSources {
		totalAmp += src.amp
	}
	invTotalAmp := 1.0 / (2.0 * totalAmp)

	for y := 0; y < m.height; y++ {
		for x := 0; x < m.width; x++ {
			// Normalized coordinates
			nx := float64(x) / w
			ny := float64(y) / h

			// Sum wave contributions
			var combined float64
			var primaryDist float64

			for i, src := range waveSources {
				dx := nx - src.cx
				dy := (ny - src.cy) * ySquash // squash y for terminal aspect ratio
				dist := math.Sqrt(dx*dx + dy*dy)

				if i == 0 {
					primaryDist = dist
				}

				wave := math.Sin(dist*src.freq-m.phase*src.speed) * src.amp
				combined += wave
			}

			// Normalize from [-totalAmp, totalAmp] → [0, 1]
			normalized := (combined + totalAmp) * invTotalAmp

			// Radial falloff from primary source
			falloff := math.Max(0.08, 1.0-primaryDist*falloffPower)
			value := normalized * falloff

			// Clamp and map to character index
			idx := int(value * float64(numChars))
			if idx < 0 {
				idx = 0
			}
			if idx >= numChars {
				idx = numChars - 1
			}

			b.WriteString(m.styles[idx].Render(string(chars[idx])))
		}

		if y < m.height-1 {
			b.WriteByte('\n')
		}
	}

	// Overlay the title centered
	wave := b.String()
	wave = overlayTitle(wave, m.width, m.height, m.title)

	// Status bar hint
	hint := lipgloss.NewStyle().
		Foreground(lipgloss.Color("#555570")).
		Render("  [1] teal  [2] purple  [q] quit")

	return wave + "\n" + hint
}

// ─────────────────────────────────────────────
// Title overlay
// ─────────────────────────────────────────────

func overlayTitle(bg string, width, height int, title string) string {
	lines := strings.Split(bg, "\n")
	if len(lines) == 0 {
		return bg
	}

	// Build the styled title
	titleStyle := lipgloss.NewStyle().
		Foreground(lipgloss.Color("#cdd6f4")).
		Bold(true)

	subtitleStyle := lipgloss.NewStyle().
		Foreground(lipgloss.Color("#585878"))

	renderedTitle := titleStyle.Render(title)
	renderedSub := subtitleStyle.Render("─── spectrum cli ───")

	// Calculate center positions
	titleRow := height/2 - 1
	subRow := height/2 + 1

	if titleRow >= 0 && titleRow < len(lines) {
		lines[titleRow] = placeCentered(lines[titleRow], renderedTitle, width, lipgloss.Width(renderedTitle))
	}
	if subRow >= 0 && subRow < len(lines) {
		lines[subRow] = placeCentered(lines[subRow], renderedSub, width, lipgloss.Width(renderedSub))
	}

	return strings.Join(lines, "\n")
}

func placeCentered(line, content string, lineWidth, contentWidth int) string {
	pad := (lineWidth - contentWidth) / 2
	if pad < 0 {
		pad = 0
	}

	// Build: [padding spaces] + content + [remaining spaces]
	padStyle := lipgloss.NewStyle().Foreground(lipgloss.Color("#1e1e2e"))
	left := padStyle.Render(strings.Repeat(" ", pad))
	right := padStyle.Render(strings.Repeat(" ", lineWidth-pad-contentWidth))

	return left + content + right
}

// ─────────────────────────────────────────────
// Main
// ─────────────────────────────────────────────

func main() {
	p := tea.NewProgram(initialModel(), tea.WithAltScreen())
	if _, err := p.Run(); err != nil {
		fmt.Fprintf(os.Stderr, "Error: %v\n", err)
		os.Exit(1)
	}
}
