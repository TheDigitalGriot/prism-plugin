import { useState, useEffect, useRef, useCallback } from "react";

const CHARS = [" ", ".", ":", "-", "=", "+", "*", "#", "%"];

const PALETTES = {
  teal: {
    name: "Codex Teal",
    bg: "#1e1e2e",
    colors: ["#1e1e2e","#2a2a3e","#3a3a50","#4a4a62","#555575","#656588","#7a7a9a","#7aa8be","#88c0d0"],
    title: "#cdd6f4",
    sub: "#585878",
  },
  purple: {
    name: "Prism Purple",
    bg: "#1a1a2e",
    colors: ["#1a1a2e","#2a2a42","#3a3a55","#4a4a68","#5a5a7b","#6a6a8e","#7a7aa2","#9a7abc","#b48eda"],
    title: "#e0d0f0",
    sub: "#5a5878",
  },
  green: {
    name: "Terminal Green",
    bg: "#0c140c",
    colors: ["#0c140c","#1a2a1a","#2a3a2a","#3a4a3a","#4a5e4a","#5a6e5a","#6a8a6a","#7aba7a","#88d888"],
    title: "#c0e8c0",
    sub: "#3a5a3a",
  },
  rose: {
    name: "Warm Rose",
    bg: "#1e1818",
    colors: ["#1e1818","#2e2424","#3e3434","#504646","#625858","#746a6a","#867c7c","#b89090","#d0a0a0"],
    title: "#f0d8d8",
    sub: "#6a5858",
  },
  spectrum: {
    name: "Spectrum",
    bg: "#121220",
    colors: ["#121220","#1e1e38","#2e2e50","#424268","#565680","#6a6a98","#8080b0","#6eaad0","#5ec4e8"],
    title: "#d0dff0",
    sub: "#4a4a70",
  },
};

const DEFAULT_PARAMS = {
  // Wave sources
  cx1: 0.40, cy1: 0.30, freq1: 38.0, speed1: 1.0, amp1: 1.0,
  cx2: 0.70, cy2: 0.60, freq2: 26.0, speed2: 1.3, amp2: 0.45,
  cx3: 0.20, cy3: 0.75, freq3: 32.0, speed3: 0.7, amp3: 0.30,
  // Global
  phaseStep: 0.10,
  ySquash: 0.45,
  falloff: 0.70,
  fontSize: 11,
};

export default function AsciiWave() {
  const canvasRef = useRef(null);
  const phaseRef = useRef(0);
  const animRef = useRef(null);
  const [palette, setPalette] = useState("teal");
  const [params, setParams] = useState(DEFAULT_PARAMS);
  const [showControls, setShowControls] = useState(false);
  const [fps, setFps] = useState(0);
  const lastTimeRef = useRef(performance.now());
  const frameCountRef = useRef(0);

  const pal = PALETTES[palette];

  const updateParam = (key, value) => {
    setParams(p => ({ ...p, [key]: value }));
  };

  const renderFrame = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");

    const dpr = window.devicePixelRatio || 1;
    const rect = canvas.getBoundingClientRect();
    canvas.width = rect.width * dpr;
    canvas.height = rect.height * dpr;
    ctx.scale(dpr, dpr);

    const w = rect.width;
    const h = rect.height;

    // Fill background
    ctx.fillStyle = pal.bg;
    ctx.fillRect(0, 0, w, h);

    const size = params.fontSize;
    ctx.font = `${size}px "Cascadia Code", "JetBrains Mono", "Fira Code", "SF Mono", "Consolas", monospace`;
    ctx.textBaseline = "top";

    const charW = size * 0.6;
    const charH = size * 1.2;
    const cols = Math.ceil(w / charW);
    const rows = Math.ceil(h / charH);

    const sources = [
      { cx: params.cx1, cy: params.cy1, freq: params.freq1, speed: params.speed1, amp: params.amp1 },
      { cx: params.cx2, cy: params.cy2, freq: params.freq2, speed: params.speed2, amp: params.amp2 },
      { cx: params.cx3, cy: params.cy3, freq: params.freq3, speed: params.speed3, amp: params.amp3 },
    ];

    const totalAmp = sources.reduce((s, src) => s + src.amp, 0);
    const phase = phaseRef.current;

    for (let row = 0; row < rows; row++) {
      for (let col = 0; col < cols; col++) {
        const nx = col / cols;
        const ny = row / rows;

        let combined = 0;
        let primaryDist = 0;

        for (let i = 0; i < sources.length; i++) {
          const src = sources[i];
          const dx = nx - src.cx;
          const dy = (ny - src.cy) * params.ySquash;
          const dist = Math.sqrt(dx * dx + dy * dy);

          if (i === 0) primaryDist = dist;

          combined += Math.sin(dist * src.freq - phase * src.speed) * src.amp;
        }

        const normalized = (combined + totalAmp) / (2.0 * totalAmp);
        const falloff = Math.max(0.08, 1.0 - primaryDist * params.falloff);
        const value = normalized * falloff;

        let idx = Math.floor(value * CHARS.length);
        idx = Math.max(0, Math.min(CHARS.length - 1, idx));

        ctx.fillStyle = pal.colors[idx];
        ctx.fillText(CHARS[idx], col * charW, row * charH);
      }
    }

    // Title overlay
    const titleSize = Math.max(28, Math.min(56, w * 0.06));
    ctx.font = `bold ${titleSize}px "Inter", "Segoe UI", system-ui, sans-serif`;
    ctx.textBaseline = "middle";
    ctx.textAlign = "center";
    ctx.fillStyle = pal.title;
    ctx.fillText("Prism", w / 2, h * 0.45);

    ctx.font = `${titleSize * 0.35}px "Cascadia Code", "JetBrains Mono", monospace`;
    ctx.fillStyle = pal.sub;
    ctx.fillText("─── spectrum cli ───", w / 2, h * 0.45 + titleSize * 0.8);

    // Advance phase
    phaseRef.current += params.phaseStep;

    // FPS counter
    frameCountRef.current++;
    const now = performance.now();
    if (now - lastTimeRef.current > 1000) {
      setFps(frameCountRef.current);
      frameCountRef.current = 0;
      lastTimeRef.current = now;
    }

    animRef.current = requestAnimationFrame(renderFrame);
  }, [pal, params]);

  useEffect(() => {
    animRef.current = requestAnimationFrame(renderFrame);
    return () => {
      if (animRef.current) cancelAnimationFrame(animRef.current);
    };
  }, [renderFrame]);

  const Slider = ({ label, param, min, max, step }) => (
    <div className="flex items-center gap-2 text-xs">
      <span className="w-16 text-right opacity-60 shrink-0">{label}</span>
      <input
        type="range"
        min={min} max={max} step={step}
        value={params[param]}
        onChange={e => updateParam(param, parseFloat(e.target.value))}
        className="flex-1 h-1 accent-sky-400"
      />
      <span className="w-10 text-right font-mono opacity-40">{params[param].toFixed(2)}</span>
    </div>
  );

  return (
    <div className="w-full h-screen flex flex-col" style={{ background: "#0a0a14" }}>
      {/* Canvas */}
      <div className="flex-1 relative">
        <canvas
          ref={canvasRef}
          className="absolute inset-0 w-full h-full"
        />

        {/* FPS badge */}
        <div className="absolute top-2 right-2 px-2 py-0.5 rounded text-xs font-mono"
          style={{ background: "rgba(0,0,0,0.5)", color: "#555575" }}>
          {fps} fps
        </div>

        {/* Toggle controls */}
        <button
          onClick={() => setShowControls(!showControls)}
          className="absolute top-2 left-2 px-2 py-0.5 rounded text-xs"
          style={{ background: "rgba(0,0,0,0.5)", color: "#888" }}>
          {showControls ? "▼ Hide Controls" : "▶ Show Controls"}
        </button>
      </div>

      {/* Controls panel */}
      {showControls && (
        <div className="shrink-0 p-3 space-y-3 overflow-y-auto"
          style={{ background: "#12121e", color: "#aaa", maxHeight: "50vh", borderTop: "1px solid #2a2a3e" }}>

          {/* Palette picker */}
          <div>
            <div className="text-xs font-semibold mb-2 opacity-50 uppercase tracking-wider">Palette</div>
            <div className="flex gap-1 flex-wrap">
              {Object.entries(PALETTES).map(([key, p]) => (
                <button
                  key={key}
                  onClick={() => setPalette(key)}
                  className="px-2 py-1 rounded text-xs transition-all"
                  style={{
                    background: palette === key ? p.colors[7] : "#1e1e2e",
                    color: palette === key ? "#fff" : "#666",
                    border: `1px solid ${palette === key ? p.colors[7] : "#2a2a3e"}`,
                  }}>
                  {p.name}
                </button>
              ))}
            </div>
          </div>

          {/* Wave Sources */}
          <div className="grid grid-cols-1 gap-3" style={{ gridTemplateColumns: "repeat(auto-fit, minmax(260px, 1fr))" }}>
            {[1, 2, 3].map(i => (
              <div key={i} className="space-y-1 p-2 rounded" style={{ background: "#1a1a28" }}>
                <div className="text-xs font-semibold opacity-50 mb-1">
                  Wave {i} {i === 1 ? "(primary)" : i === 2 ? "(secondary)" : "(tertiary)"}
                </div>
                <Slider label="center X" param={`cx${i}`} min={0} max={1} step={0.01} />
                <Slider label="center Y" param={`cy${i}`} min={0} max={1} step={0.01} />
                <Slider label="freq" param={`freq${i}`} min={5} max={80} step={0.5} />
                <Slider label="speed" param={`speed${i}`} min={0.1} max={3} step={0.05} />
                <Slider label="amp" param={`amp${i}`} min={0} max={1.5} step={0.05} />
              </div>
            ))}
          </div>

          {/* Global params */}
          <div className="space-y-1 p-2 rounded" style={{ background: "#1a1a28" }}>
            <div className="text-xs font-semibold opacity-50 mb-1">Global</div>
            <Slider label="speed" param="phaseStep" min={0.01} max={0.3} step={0.005} />
            <Slider label="y squash" param="ySquash" min={0.1} max={1} step={0.01} />
            <Slider label="falloff" param="falloff" min={0} max={2} step={0.05} />
            <Slider label="font size" param="fontSize" min={6} max={20} step={1} />
          </div>

          {/* Export params as Go code */}
          <button
            onClick={() => {
              const code = `// Wave sources
var waveSources = []waveSource{
\t{cx: ${params.cx1}, cy: ${params.cy1}, freq: ${params.freq1}, speed: ${params.speed1}, amp: ${params.amp1}},
\t{cx: ${params.cx2}, cy: ${params.cy2}, freq: ${params.freq2}, speed: ${params.speed2}, amp: ${params.amp2}},
\t{cx: ${params.cx3}, cy: ${params.cy3}, freq: ${params.freq3}, speed: ${params.speed3}, amp: ${params.amp3}},
}

const (
\tphaseStep    = ${params.phaseStep}
\tySquash      = ${params.ySquash}
\tfalloffPower = ${params.falloff}
)`;
              navigator.clipboard.writeText(code);
            }}
            className="px-3 py-1.5 rounded text-xs font-mono"
            style={{ background: "#2a2a40", color: "#88c0d0", border: "1px solid #3a3a55" }}>
            📋 Copy as Go Constants
          </button>
        </div>
      )}
    </div>
  );
}
