package main

import (
	"fmt"
	"math"
	"math/rand"
	"os"
	"strings"
	"time"

	tea "github.com/charmbracelet/bubbletea"
	"github.com/charmbracelet/lipgloss"
)

// ─────────────────────────────────────────────────────
// ASCII density ramp
// ─────────────────────────────────────────────────────

var densityChars = []rune{' ', '.', '·', ':', '-', '=', '+', '*', '#', '%', '@'}

// ─────────────────────────────────────────────────────
// Configuration constants
// ─────────────────────────────────────────────────────

const (
	tickInterval = 66 * time.Millisecond // ~15 FPS

	// Icosahedron
	icoX         = 0.36
	icoY         = 0.50
	icoScale     = 0.11
	icoRotSpeedY = 0.15
	icoRotSpeedX = 0.08
	icoRotSpeedZ = 0.05
	icoBright    = 0.70
	icoBloom     = 0.25

	// Beam
	beamWidth      = 0.055
	beamRays       = 6
	beamSpeed      = 0.010
	beamGlowRadius = 3
	beamBrightness = 0.45
	particleCount  = 200

	// Wave field
	waveFreq1     = 34.0
	waveFreq2     = 26.0
	waveSpeed     = 1.0
	waveSecondary = 0.30

	// Spectral coloring
	spectralSpread = 1.0
	hueStart       = 275.0
	hueEnd         = 0.0
	colorIntensity = 0.35
	peakBoost      = 0.15
	greyMin        = 0.05
	greyMax        = 0.32

	// Global
	phaseStep       = 0.08
	speedMult       = 1.0
	falloffPower    = 0.50
	ySquash         = 0.45
	transitionWidth = 0.08

	// Halo
	haloPadX  = 3
	haloPadY  = 1
	haloFadeX = 10
	haloFadeY = 4

	// Perspective
	perspDist = 3.5
)

// Background color (dark near-black)
const (
	bgR = 10
	bgG = 9
	bgB = 16
)

// ─────────────────────────────────────────────────────
// Icosahedron geometry
// ─────────────────────────────────────────────────────

type vec3 [3]float64

var icoVerts []vec3
var icoEdges [][2]int

func init() {
	phi := (1.0 + math.Sqrt(5.0)) / 2.0
	raw := [][3]float64{
		{-1, phi, 0}, {1, phi, 0}, {-1, -phi, 0}, {1, -phi, 0},
		{0, -1, phi}, {0, 1, phi}, {0, -1, -phi}, {0, 1, -phi},
		{phi, 0, -1}, {phi, 0, 1}, {-phi, 0, -1}, {-phi, 0, 1},
	}
	// Normalize to unit sphere
	l := math.Sqrt(1.0 + phi*phi)
	icoVerts = make([]vec3, len(raw))
	for i, v := range raw {
		icoVerts[i] = vec3{v[0] / l, v[1] / l, v[2] / l}
	}

	icoEdges = [][2]int{
		{0, 1}, {0, 5}, {0, 7}, {0, 10}, {0, 11},
		{1, 5}, {1, 7}, {1, 8}, {1, 9},
		{2, 3}, {2, 4}, {2, 6}, {2, 10}, {2, 11},
		{3, 4}, {3, 6}, {3, 8}, {3, 9},
		{4, 5}, {4, 9}, {4, 11},
		{5, 9}, {5, 11},
		{6, 7}, {6, 8}, {6, 10},
		{7, 8}, {7, 10},
		{8, 9},
		{10, 11},
	}
}

// ─────────────────────────────────────────────────────
// 3D rotation
// ─────────────────────────────────────────────────────

func rotateY(v vec3, a float64) vec3 {
	c, s := math.Cos(a), math.Sin(a)
	return vec3{c*v[0] + s*v[2], v[1], -s*v[0] + c*v[2]}
}

func rotateX(v vec3, a float64) vec3 {
	c, s := math.Cos(a), math.Sin(a)
	return vec3{v[0], c*v[1] - s*v[2], s*v[1] + c*v[2]}
}

func rotateZ(v vec3, a float64) vec3 {
	c, s := math.Cos(a), math.Sin(a)
	return vec3{c*v[0] - s*v[1], s*v[0] + c*v[1], v[2]}
}

// ─────────────────────────────────────────────────────
// Projected vertex / edge
// ─────────────────────────────────────────────────────

type projectedVert struct {
	x, y float64 // normalized screen coords
	z    float64 // depth (for sorting)
	pf   float64 // perspective factor (front=brighter)
}

type projectedEdge struct {
	ax, ay, bx, by float64
	depth          float64
	frontFactor    float64
}

// ─────────────────────────────────────────────────────
// Beam particle
// ─────────────────────────────────────────────────────

type beamParticle struct {
	x, y       float64
	vx, vy     float64
	brightness float64
	life       float64
	maxLife    float64
}

func (p *beamParticle) update(dt float64) {
	p.x += p.vx * dt
	p.y += p.vy * dt
	p.life -= dt
}

func (p *beamParticle) alive() bool {
	return p.life > 0 && p.x < 1.1
}

// ─────────────────────────────────────────────────────
// Cell grid
// ─────────────────────────────────────────────────────

type cell struct {
	ch      rune
	r, g, b uint8
}

// ─────────────────────────────────────────────────────
// HSL → RGB
// ─────────────────────────────────────────────────────

func hslToRGB(h, s, l float64) (uint8, uint8, uint8) {
	h = math.Mod(math.Mod(h, 360)+360, 360)
	s /= 100
	l /= 100
	c := (1.0 - math.Abs(2.0*l-1.0)) * s
	x := c * (1.0 - math.Abs(math.Mod(h/60.0, 2)-1.0))
	m := l - c/2.0

	var r, g, b float64
	switch {
	case h < 60:
		r, g, b = c, x, 0
	case h < 120:
		r, g, b = x, c, 0
	case h < 180:
		r, g, b = 0, c, x
	case h < 240:
		r, g, b = 0, x, c
	case h < 300:
		r, g, b = x, 0, c
	default:
		r, g, b = c, 0, x
	}
	return uint8(math.Round((r + m) * 255)),
		uint8(math.Round((g + m) * 255)),
		uint8(math.Round((b + m) * 255))
}

// ─────────────────────────────────────────────────────
// Distance from point to line segment
// ─────────────────────────────────────────────────────

func distToSegment(px, py, ax, ay, bx, by float64) float64 {
	dx := bx - ax
	dy := by - ay
	lenSq := dx*dx + dy*dy
	if lenSq == 0 {
		ddx := px - ax
		ddy := py - ay
		return math.Sqrt(ddx*ddx + ddy*ddy)
	}
	t := ((px-ax)*dx + (py-ay)*dy) / lenSq
	t = math.Max(0, math.Min(1, t))
	closestX := ax + t*dx
	closestY := ay + t*dy
	ddx := px - closestX
	ddy := py - closestY
	return math.Sqrt(ddx*ddx + ddy*ddy)
}

// ─────────────────────────────────────────────────────
// Model
// ─────────────────────────────────────────────────────

type model struct {
	width     int
	height    int
	phase     float64
	particles []beamParticle
	spawnAcc  float64
	grid      [][]cell // [y][x]
	rng       *rand.Rand
}

type tickMsg time.Time

func tickCmd() tea.Cmd {
	return tea.Tick(tickInterval, func(t time.Time) tea.Msg {
		return tickMsg(t)
	})
}

func initialModel() model {
	return model{
		rng:       rand.New(rand.NewSource(time.Now().UnixNano())),
		particles: make([]beamParticle, 0, particleCount*2),
	}
}

func (m *model) ensureGrid() {
	if len(m.grid) == m.height && (m.height == 0 || len(m.grid[0]) == m.width) {
		return
	}
	m.grid = make([][]cell, m.height)
	for y := range m.grid {
		m.grid[y] = make([]cell, m.width)
	}
}

// ─────────────────────────────────────────────────────
// Bubble Tea lifecycle
// ─────────────────────────────────────────────────────

func (m model) Init() tea.Cmd {
	return tickCmd()
}

func (m model) Update(msg tea.Msg) (tea.Model, tea.Cmd) {
	switch msg := msg.(type) {
	case tea.KeyMsg:
		switch msg.String() {
		case "q", "esc", "ctrl+c":
			return m, tea.Quit
		}
	case tea.WindowSizeMsg:
		m.width = msg.Width
		m.height = msg.Height
		m.ensureGrid()
	case tickMsg:
		m.phase += phaseStep * speedMult
		m.updateParticles()
		return m, tickCmd()
	}
	return m, nil
}

// ─────────────────────────────────────────────────────
// Particle simulation
// ─────────────────────────────────────────────────────

func (m *model) updateParticles() {
	dt := speedMult

	// Update existing particles
	alive := m.particles[:0]
	for i := range m.particles {
		m.particles[i].update(dt)
		if m.particles[i].alive() {
			alive = append(alive, m.particles[i])
		}
	}
	m.particles = alive

	// Entry point (where beam converges toward icosahedron)
	entryX := icoX - icoScale*0.9
	entryY := icoY

	// Spawn new particles
	m.spawnAcc += float64(particleCount) * 0.12 * dt
	for m.spawnAcc >= 1 && len(m.particles) < particleCount*2 {
		m.spawnAcc -= 1

		for r := 0; r < beamRays; r++ {
			rayOff := (float64(r)/math.Max(1, float64(beamRays-1)) - 0.5) * beamWidth
			sx := -0.03 + m.rng.Float64()*0.02
			sy := entryY + rayOff + (m.rng.Float64()-0.5)*0.008

			dx := entryX - sx
			dy := (entryY + rayOff*0.15) - sy
			l := math.Sqrt(dx*dx + dy*dy)
			spd := beamSpeed * (0.8 + m.rng.Float64()*0.4)

			m.particles = append(m.particles, beamParticle{
				x:          sx,
				y:          sy,
				vx:         (dx / l) * spd,
				vy:         (dy / l) * spd,
				brightness: 0.3 + m.rng.Float64()*0.7,
				life:       l / spd * 1.2,
				maxLife:    l / spd * 1.2,
			})
		}
	}
}

// ─────────────────────────────────────────────────────
// View — main render pipeline
// ─────────────────────────────────────────────────────

func (m model) View() string {
	if m.width < 4 || m.height < 4 {
		return ""
	}
	m.ensureGrid()

	cols := m.width
	rows := m.height
	phase := m.phase
	numChars := len(densityChars)

	// Character aspect ratio (terminal chars are ~2:1 height:width)
	charAspect := 0.5 // charW / charH

	// ── Phase 1: Project icosahedron ──
	projected := make([]projectedVert, len(icoVerts))
	for i, v := range icoVerts {
		r := rotateY(v, phase*icoRotSpeedY)
		r = rotateX(r, phase*icoRotSpeedX+0.3) // slight tilt
		r = rotateZ(r, phase*icoRotSpeedZ)

		pf := perspDist / (perspDist + r[2])
		sx := icoX + r[0]*icoScale*pf
		sy := icoY + r[1]*icoScale*pf/charAspect

		projected[i] = projectedVert{x: sx, y: sy, z: r[2], pf: pf}
	}

	// Build projected edges
	edges := make([]projectedEdge, len(icoEdges))
	for i, e := range icoEdges {
		a, b := projected[e[0]], projected[e[1]]
		edges[i] = projectedEdge{
			ax: a.x, ay: a.y, bx: b.x, by: b.y,
			depth:       (a.z + b.z) / 2,
			frontFactor: (a.pf + b.pf) / 2,
		}
	}

	// Entry/exit points for beam/wave transition
	exitX := icoX + icoScale*0.9
	exitY := icoY

	// ── Phase 2: Build beam light grid ──
	beamGrid := make([]float64, rows*cols)

	for pi := range m.particles {
		p := &m.particles[pi]
		lifeRatio := p.life / p.maxLife
		fade := math.Min(1, (1-lifeRatio)*5) * math.Min(1, lifeRatio*4) * p.brightness * beamBrightness
		cx := int(p.x * float64(cols))
		cy := int(p.y * float64(rows))

		gr := beamGlowRadius
		for dy := -gr; dy <= gr; dy++ {
			gy := cy + dy
			if gy < 0 || gy >= rows {
				continue
			}
			for dx := -gr; dx <= gr; dx++ {
				gx := cx + dx
				if gx < 0 || gx >= cols {
					continue
				}
				dist := math.Sqrt(float64(dx*dx) + float64(dy*dy)*1.6*1.6/3.0)
				if dist > float64(gr) {
					continue
				}
				beamGrid[gy*cols+gx] += fade * math.Pow(math.Max(0, 1-dist/float64(gr)), 1.4)
			}
		}
	}

	// ── Phase 3: Title halo bounds ──
	titleText := "P R I S M"
	subText := "─── spectrum cli ───"
	centerRow := rows / 2
	titleRow := centerRow - 1
	subRow := centerRow + 1
	titleRunes := []rune(titleText)
	subRunes := []rune(subText)
	titleColStart := (cols - len(titleRunes)) / 2
	subColStart := (cols - len(subRunes)) / 2

	// Halo bounding box
	hR0, hR1, hC0, hC1 := titleRow, subRow, titleColStart, titleColStart+len(titleRunes)-1
	if sc := subColStart; sc < hC0 {
		hC0 = sc
	}
	if se := subColStart + len(subRunes) - 1; se > hC1 {
		hC1 = se
	}

	// ── Phase 4: Render every cell ──
	for row := 0; row < rows; row++ {
		ny := float64(row) / float64(rows)
		for col := 0; col < cols; col++ {
			nx := float64(col) / float64(cols)

			// ── Icosahedron wireframe glow ──
			var icoGlow, icoBloomVal float64
			for _, edge := range edges {
				d := distToSegment(nx, ny, edge.ax, edge.ay, edge.bx, edge.by)
				depthBright := 0.3 + 0.7*edge.frontFactor
				bright := depthBright * icoBright
				g := math.Max(0, 1.0-d*180) * bright * 0.5
				if g > icoGlow {
					icoGlow = g
				}
				bl := math.Max(0, 1.0-d*40) * bright * icoBloom * 0.3
				if bl > icoBloomVal {
					icoBloomVal = bl
				}
			}
			totalIco := icoGlow + icoBloomVal

			// Transition blend: left=beam, right=wave
			transNorm := (nx - exitX) / math.Max(0.001, transitionWidth)
			waveMix := math.Max(0, math.Min(1, transNorm))
			beamMix := 1.0 - waveMix

			// ── Wave field (right side) ──
			var wR, wG, wB, waveDensity float64
			if waveMix > 0 {
				wdx := nx - exitX
				wdy := (ny - exitY) * ySquash
				wDist := math.Sqrt(wdx*wdx + wdy*wdy)
				wave1 := math.Sin(wDist*waveFreq1-phase*waveSpeed)*0.5 + 0.5

				wdx2 := nx - (exitX + 0.15)
				wdy2 := (ny - exitY) * ySquash
				wDist2 := math.Sqrt(wdx2*wdx2 + wdy2*wdy2)
				wave2 := math.Sin(wDist2*waveFreq2-phase*waveSpeed*0.7)*0.5 + 0.5

				combined := wave1*(1.0-waveSecondary) + wave2*waveSecondary
				falloff := math.Max(0.10, 1.0-wDist*falloffPower)
				waveDensity = combined * falloff

				// Spectral coloring based on exit angle
				angle := math.Atan2(ny-exitY, nx-exitX)
				normalizedAngle := (angle / math.Pi) * spectralSpread
				hueT := normalizedAngle*0.5 + 0.5
				hue := hueStart + hueT*(hueEnd-hueStart)
				sr, sg, sb := hslToRGB(hue, 55, 50)

				grey := greyMin + waveDensity*(greyMax-greyMin)
				colorAmt := waveDensity*colorIntensity + math.Pow(waveDensity, 3)*peakBoost

				wR = float64(bgR) + grey*255 + (float64(sr)-128)*colorAmt
				wG = float64(bgG) + grey*255 + (float64(sg)-128)*colorAmt
				wB = float64(bgB) + grey*255 + (float64(sb)-128)*colorAmt
			}

			// ── Beam field (left side) ──
			var bR, bG, bB float64
			var beamDensity float64

			if beamMix > 0 {
				bVal := beamGrid[row*cols+col]
				if bVal > 0.01 {
					beamDensity = math.Min(1.0, bVal)
					grey := greyMin + beamDensity*(greyMax-greyMin)
					bR = float64(bgR) + grey*255 + (175-128)*beamDensity*0.3
					bG = float64(bgG) + grey*255 + (172-128)*beamDensity*0.3
					bB = float64(bgB) + grey*255 + (195-128)*beamDensity*0.3
				} else {
					// Ambient left-side wave
					entryXLocal := icoX - icoScale*0.9
					adx := nx - entryXLocal
					ady := (ny - icoY) * ySquash
					aDist := math.Sqrt(adx*adx + ady*ady)
					ambientWave := math.Sin(aDist*20-phase*0.4)*0.5 + 0.5
					ambientDensity := ambientWave * 0.25 * math.Max(0.1, 1.0-aDist*0.8)
					beamDensity = ambientDensity
					grey := greyMin + ambientDensity*(greyMax-greyMin)*0.5
					bR = float64(bgR) + grey*160
					bG = float64(bgG) + grey*160
					bB = float64(bgB) + grey*170
				}
			}

			// ── Blend beam + wave ──
			density := beamDensity*beamMix + waveDensity*waveMix
			finalR := bR*beamMix + wR*waveMix
			finalG := bG*beamMix + wG*waveMix
			finalB := bB*beamMix + wB*waveMix

			// Add icosahedron glow (purple-tinted)
			finalR += totalIco * 95
			finalG += totalIco * 85
			finalB += totalIco * 165

			// ── Halo dimming ──
			haloMask := 1.0
			{
				var ddx, ddy float64
				if col < hC0-haloPadX {
					ddx = float64(hC0-haloPadX-col) / float64(haloFadeX)
				} else if col > hC1+haloPadX {
					ddx = float64(col-hC1-haloPadX) / float64(haloFadeX)
				}
				if row < hR0-haloPadY {
					ddy = float64(hR0-haloPadY-row) / float64(haloFadeY)
				} else if row > hR1+haloPadY {
					ddy = float64(row-hR1-haloPadY) / float64(haloFadeY)
				}
				hd := math.Sqrt(ddx*ddx + ddy*ddy)
				if hd < 1.0 {
					haloMask = hd
				}
			}

			// Character index from density
			charIdx := int(density * float64(numChars))
			if charIdx < 0 {
				charIdx = 0
			} else if charIdx >= numChars {
				charIdx = numChars - 1
			}
			if haloMask < 1.0 {
				charIdx = int(math.Max(0, math.Round(float64(charIdx)*haloMask)))
			}

			// Final color with halo blend toward background
			oR := clampByte(finalR*haloMask + float64(bgR)*(1-haloMask))
			oG := clampByte(finalG*haloMask + float64(bgG)*(1-haloMask))
			oB := clampByte(finalB*haloMask + float64(bgB)*(1-haloMask))

			m.grid[row][col] = cell{
				ch: densityChars[charIdx],
				r:  oR, g: oG, b: oB,
			}
		}
	}

	// ── Phase 5: Stamp icosahedron wireframe ──
	// Sort edges back-to-front for proper overdraw
	sortEdgesBackToFront(edges)

	for _, edge := range edges {
		depthBright := 0.3 + 0.7*edge.frontFactor
		bright := depthBright * icoBright * 85
		er := clampByte(float64(bgR) + bright)
		eg := clampByte(float64(bgG) + bright*0.9)
		eb := clampByte(float64(bgB) + bright*1.5)

		// Determine line character from angle
		edgeDx := edge.bx - edge.ax
		edgeDy := edge.by - edge.ay
		angle := math.Atan2(edgeDy, edgeDx)
		a := math.Mod(math.Mod(angle, math.Pi)+math.Pi, math.Pi)

		var ch rune
		switch {
		case a < 0.35 || a > 2.79:
			ch = '─'
		case a > 1.2 && a < 1.95:
			ch = '│'
		case a >= 0.35 && a <= 1.2:
			ch = '╲'
		default:
			ch = '╱'
		}

		steps := int(math.Ceil(math.Max(math.Abs(edgeDx)*float64(cols), math.Abs(edgeDy)*float64(rows)) * 2))
		for i := 0; i <= steps; i++ {
			t := float64(i) / math.Max(1, float64(steps))
			ec := int((edge.ax + edgeDx*t) * float64(cols))
			erow := int((edge.ay + edgeDy*t) * float64(rows))
			if ec >= 0 && ec < cols && erow >= 0 && erow < rows {
				m.grid[erow][ec] = cell{ch: ch, r: er, g: eg, b: eb}
			}
		}
	}

	// ── Phase 6: Stamp vertex dots ──
	for _, v := range projected {
		depthBright := 0.3 + 0.7*v.pf
		bright := depthBright * icoBright * 100
		vr := clampByte(float64(bgR) + bright)
		vg := clampByte(float64(bgG) + bright*0.9)
		vb := clampByte(float64(bgB) + bright*1.6)

		vc := int(v.x * float64(cols))
		vrow := int(v.y * float64(rows))
		if vc >= 0 && vc < cols && vrow >= 0 && vrow < rows {
			m.grid[vrow][vc] = cell{ch: '◆', r: vr, g: vg, b: vb}
		}
	}

	// ── Phase 7: Stamp title text (spectral gradient) ──
	for i, ch := range titleRunes {
		col := titleColStart + i
		if col < 0 || col >= cols || titleRow < 0 || titleRow >= rows {
			continue
		}
		t := float64(i) / math.Max(1, float64(len(titleRunes)-1))
		hue := hueStart + t*(hueEnd-hueStart)
		tr, tg, tb := hslToRGB(hue, 18, 80)
		m.grid[titleRow][col] = cell{ch: ch, r: tr, g: tg, b: tb}
	}

	// Subtitle
	for i, ch := range subRunes {
		col := subColStart + i
		if col < 0 || col >= cols || subRow < 0 || subRow >= rows {
			continue
		}
		m.grid[subRow][col] = cell{
			ch: ch,
			r:  clampByte(float64(bgR) + 42),
			g:  clampByte(float64(bgG) + 40),
			b:  clampByte(float64(bgB) + 50),
		}
	}

	// ── Phase 8: Render grid to ANSI string ──
	return m.renderGrid()
}

// ─────────────────────────────────────────────────────
// Grid → string with ANSI true color + run batching
//
// Uses direct ANSI escape sequences (CSI 38;2;R;G;B m)
// for maximum throughput. Adjacent cells sharing the
// same RGB color are batched into a single escape
// sequence to minimize output size.
// ─────────────────────────────────────────────────────

func (m model) renderGrid() string {
	var b strings.Builder
	b.Grow(m.width * m.height * 20)

	// Reserve last line for status bar
	renderHeight := m.height - 1
	if renderHeight < 1 {
		renderHeight = 1
	}

	var lastR, lastG, lastB uint8
	firstCell := true

	for y := 0; y < renderHeight; y++ {
		row := m.grid[y]
		for x := 0; x < m.width; x++ {
			c := row[x]
			// Only emit color change when RGB differs from previous cell
			if firstCell || c.r != lastR || c.g != lastG || c.b != lastB {
				fmt.Fprintf(&b, "\x1b[38;2;%d;%d;%dm", c.r, c.g, c.b)
				lastR, lastG, lastB = c.r, c.g, c.b
				firstCell = false
			}
			b.WriteRune(c.ch)
		}
		if y < renderHeight-1 {
			b.WriteByte('\n')
		}
	}

	// Reset color
	b.WriteString("\x1b[0m")

	// Status bar
	b.WriteByte('\n')
	hint := lipgloss.NewStyle().
		Foreground(lipgloss.Color("#333350")).
		Render("  [q] quit")
	b.WriteString(hint)

	return b.String()
}

// ─────────────────────────────────────────────────────
// Helpers
// ─────────────────────────────────────────────────────

func clampByte(v float64) uint8 {
	if v < 0 {
		return 0
	}
	if v > 255 {
		return 255
	}
	return uint8(math.Round(v))
}

// Simple insertion sort for small edge lists (30 edges)
func sortEdgesBackToFront(edges []projectedEdge) {
	for i := 1; i < len(edges); i++ {
		key := edges[i]
		j := i - 1
		for j >= 0 && edges[j].depth > key.depth {
			edges[j+1] = edges[j]
			j--
		}
		edges[j+1] = key
	}
}

// ─────────────────────────────────────────────────────
// Main
// ─────────────────────────────────────────────────────

func main() {
	p := tea.NewProgram(initialModel(), tea.WithAltScreen())
	if _, err := p.Run(); err != nil {
		fmt.Fprintf(os.Stderr, "Error: %v\n", err)
		os.Exit(1)
	}
}
