// cchistory — Extract and catalog Claude Code conversation history for Prism CLI.
//
// Usage:
//
//	cchistory scan                          # Full scan, output JSON catalog
//	cchistory projects                      # List all projects
//	cchistory sessions <project-name>       # List sessions for a project
//	cchistory transcript <project> <session-id>  # Dump a session transcript
//	cchistory export [--format=json|markdown|prism] [--output=path]
//	cchistory history [--limit=20]          # Show global prompt history
package main

import (
	"encoding/json"
	"flag"
	"fmt"
	"os"
	"strings"

	"github.com/spectrum-studio/cchistory/internal/export"
	"github.com/spectrum-studio/cchistory/internal/models"
	"github.com/spectrum-studio/cchistory/internal/parser"
)

const version = "0.1.0"

func main() {
	if len(os.Args) < 2 {
		printUsage()
		os.Exit(1)
	}

	// Global flags
	claudeDir := os.Getenv("CLAUDE_DIR")
	if claudeDir == "" {
		dir, err := parser.DefaultClaudeDir()
		if err != nil {
			fatal("Cannot determine Claude directory: %v", err)
		}
		claudeDir = dir
	}

	scanner := parser.NewScanner(claudeDir)

	switch os.Args[1] {
	case "scan":
		cmdScan(scanner)
	case "projects", "proj":
		cmdProjects(scanner)
	case "sessions", "sess":
		cmdSessions(scanner, os.Args[2:])
	case "transcript", "ts":
		cmdTranscript(scanner, os.Args[2:])
	case "export":
		cmdExport(scanner, os.Args[2:])
	case "history", "hist":
		cmdHistory(scanner, os.Args[2:])
	case "version":
		fmt.Printf("cchistory %s\n", version)
	case "help", "--help", "-h":
		printUsage()
	default:
		fmt.Fprintf(os.Stderr, "Unknown command: %s\n\n", os.Args[1])
		printUsage()
		os.Exit(1)
	}
}

func cmdScan(s *parser.Scanner) {
	catalog, err := s.ScanFull()
	if err != nil {
		fatal("Scan failed: %v", err)
	}

	data, err := json.MarshalIndent(catalog, "", "  ")
	if err != nil {
		fatal("JSON encode failed: %v", err)
	}
	fmt.Println(string(data))
}

func cmdProjects(s *parser.Scanner) {
	catalog, err := s.ScanFull()
	if err != nil {
		fatal("Cannot discover projects: %v", err)
	}

	projects := catalog.Projects
	if len(projects) == 0 {
		fmt.Println("No projects found.")
		return
	}

	fmt.Printf("%-30s %-8s %s\n", "PROJECT", "SESSIONS", "PATH")
	fmt.Println(strings.Repeat("─", 80))
	for _, p := range projects {
		name := p.Name
		if len(name) > 28 {
			name = name[:25] + "..."
		}
		fmt.Printf("%-30s %-8d %s\n", name, len(p.Sessions), p.RealPath)
	}
	fmt.Printf("\n%d projects found\n", len(projects))
}

func cmdSessions(s *parser.Scanner, args []string) {
	if len(args) == 0 {
		fatal("Usage: cchistory sessions <project-name>")
	}

	query := args[0]
	catalog, err := s.ScanFull()
	if err != nil {
		fatal("Cannot discover projects: %v", err)
	}

	matches := parser.FilterProjectsByName(catalog.Projects, query)
	if len(matches) == 0 {
		fatal("No projects matching '%s'", query)
	}

	for _, proj := range matches {
		fmt.Printf("\n📁 %s (%s)\n", proj.Name, proj.RealPath)
		if len(proj.Sessions) == 0 {
			fmt.Println("  No sessions found.")
			continue
		}

		fmt.Printf("  %-4s %-18s %-6s %-12s %s\n", "#", "DATE", "MSGS", "BRANCH", "SUMMARY")
		fmt.Printf("  %s\n", strings.Repeat("─", 76))
		for i, sess := range proj.Sessions {
			date := sess.UpdatedAt.Format("Jan 02 15:04")
			branch := sess.GitBranch
			if branch == "" {
				branch = "-"
			}
			if len(branch) > 10 {
				branch = branch[:10] + ".."
			}
			summary := truncate(sess.Summary, 40)
			fmt.Printf("  %-4d %-18s %-6d %-12s %s\n",
				i+1, date, sess.MessageCount, branch, summary)
		}
		fmt.Printf("\n  Session IDs for --resume:\n")
		for _, sess := range proj.Sessions {
			label := truncate(sess.Summary, 50)
			if label == "" {
				label = "(no summary)"
			}
			fmt.Printf("    %s  %s\n", sess.SessionID, label)
		}
	}
}

func cmdTranscript(s *parser.Scanner, args []string) {
	if len(args) < 2 {
		fatal("Usage: cchistory transcript <project-name> <session-id>")
	}

	query := args[0]
	sessionID := args[1]

	catalog, err := s.ScanFull()
	if err != nil {
		fatal("Cannot discover projects: %v", err)
	}

	matches := parser.FilterProjectsByName(catalog.Projects, query)
	if len(matches) == 0 {
		fatal("No projects matching '%s'", query)
	}

	proj := matches[0]
	msgs, err := s.LoadSessionTranscript(proj.DirPath, sessionID)
	if err != nil {
		// Try subagents
		subs, err2 := s.LoadSubagentTranscripts(proj.DirPath, sessionID)
		if err2 != nil || len(subs) == 0 {
			fatal("Cannot load transcript: %v", err)
		}
		fmt.Printf("⚠ No main transcript found (VS Code extension bug). Showing %d subagent transcripts:\n\n", len(subs))
		for name, subMsgs := range subs {
			fmt.Printf("── Subagent: %s (%d messages) ──\n", name, len(subMsgs))
			printMessages(subMsgs)
		}
		return
	}

	fmt.Printf("📝 Session %s — %d messages\n\n", sessionID, len(msgs))
	printMessages(msgs)
}

func cmdExport(s *parser.Scanner, args []string) {
	fs := flag.NewFlagSet("export", flag.ExitOnError)
	format := fs.String("format", "prism", "Output format: json, markdown, prism")
	output := fs.String("output", "", "Output file path (default: stdout)")
	fs.Parse(args)

	catalog, err := s.ScanFull()
	if err != nil {
		fatal("Scan failed: %v", err)
	}

	var f export.Format
	switch *format {
	case "json":
		f = export.FormatJSON
	case "markdown", "md":
		f = export.FormatMarkdown
	case "prism":
		f = export.FormatPrism
	default:
		fatal("Unknown format: %s", *format)
	}

	if *output == "" {
		// Write to stdout
		tmpFile := "/tmp/cchistory-export.tmp"
		if err := export.ExportCatalog(catalog, tmpFile, f); err != nil {
			fatal("Export failed: %v", err)
		}
		data, _ := os.ReadFile(tmpFile)
		os.Stdout.Write(data)
		os.Remove(tmpFile)
	} else {
		if err := export.ExportCatalog(catalog, *output, f); err != nil {
			fatal("Export failed: %v", err)
		}
		fmt.Fprintf(os.Stderr, "Exported to %s\n", *output)
	}
}

func cmdHistory(s *parser.Scanner, args []string) {
	fs := flag.NewFlagSet("history", flag.ExitOnError)
	limit := fs.Int("limit", 20, "Number of entries to show")
	project := fs.String("project", "", "Filter by project name")
	fs.Parse(args)

	entries, err := s.LoadHistory()
	if err != nil {
		fatal("Cannot load history: %v", err)
	}

	if *project != "" {
		query := strings.ToLower(*project)
		var filtered []models.HistoryEntry
		for _, e := range entries {
			if strings.Contains(strings.ToLower(e.ProjectPath), query) {
				filtered = append(filtered, e)
			}
		}
		entries = filtered
	}

	if len(entries) == 0 {
		fmt.Println("No history entries found.")
		return
	}

	if *limit > 0 && len(entries) > *limit {
		entries = entries[:*limit]
	}

	fmt.Printf("%-4s %-18s %-20s %-14s %s\n", "#", "DATE", "PROJECT", "SESSION", "PROMPT")
	fmt.Println(strings.Repeat("─", 100))
	for i, e := range entries {
		date := e.Timestamp.Format("Jan 02 15:04")
		proj := projectNameFromCwd(e.ProjectPath)
		if len(proj) > 18 {
			proj = proj[:18] + ".."
		}
		sessID := e.SessionID
		if len(sessID) > 12 {
			sessID = sessID[:12] + ".."
		}
		prompt := truncate(e.Prompt, 50)
		fmt.Printf("%-4d %-18s %-20s %-14s %s\n",
			i+1, date, proj, sessID, prompt)
	}
	fmt.Printf("\nShowing %d of %d total entries\n", len(entries), len(entries))
}

func printMessages(msgs []models.TranscriptMessage) {
	for _, msg := range msgs {
		role := msg.Message.Role
		if role == "" {
			role = msg.Type
		}
		text := msg.Message.GetTextContent()
		if text == "" {
			continue
		}

		// Color-code by role
		prefix := "  "
		switch role {
		case "user":
			prefix = "👤"
		case "assistant":
			prefix = "🤖"
		case "system":
			prefix = "⚙️"
		}

		// Truncate very long assistant responses for readability
		if role == "assistant" && len(text) > 500 {
			text = text[:497] + "..."
		}

		fmt.Printf("%s %s\n\n", prefix, text)
	}
}

func projectNameFromCwd(cwd string) string {
	if cwd == "" {
		return "(unknown)"
	}
	parts := strings.Split(cwd, "/")
	for i := len(parts) - 1; i >= 0; i-- {
		if parts[i] != "" {
			return parts[i]
		}
	}
	return cwd
}

func truncate(s string, maxLen int) string {
	s = strings.ReplaceAll(s, "\n", " ")
	if len(s) <= maxLen {
		return s
	}
	return s[:maxLen-3] + "..."
}

func fatal(format string, args ...interface{}) {
	fmt.Fprintf(os.Stderr, "Error: "+format+"\n", args...)
	os.Exit(1)
}

func printUsage() {
	usage := `cchistory — Extract Claude Code conversation history for Prism CLI

USAGE:
    cchistory <command> [options]

COMMANDS:
    scan                                  Full scan, output JSON catalog to stdout
    projects                              List all discovered projects
    sessions <project-name>               List sessions for a project (fuzzy match)
    transcript <project> <session-id>     Dump a session transcript
    export [flags]                        Export catalog in various formats
    history [flags]                       Show global prompt history
    version                               Print version
    help                                  Show this help

EXPORT FLAGS:
    --format=<json|markdown|prism>        Output format (default: prism)
    --output=<path>                       Output file (default: stdout)

HISTORY FLAGS:
    --limit=<n>                           Number of entries (default: 20)
    --project=<name>                      Filter by project name

ENVIRONMENT:
    CLAUDE_DIR                            Override ~/.claude directory path

EXAMPLES:
    cchistory projects
    cchistory sessions prism-tui
    cchistory export --format=prism --output=.prism/claude-sessions.json
    cchistory history --project=prism --limit=50
    cchistory transcript my-project abc123-def456

PRISM INTEGRATION:
    The 'prism' export format outputs a JSON structure designed for direct
    ingestion by Prism CLI's story/task categorization system. Pipe it into
    your .prism/ directory:

        cchistory export --format=prism > .prism/claude-sessions.json

` + "Version: " + version + "\n"

	fmt.Print(usage)
}
