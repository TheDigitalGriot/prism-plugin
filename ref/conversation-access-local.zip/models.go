// Package models defines the data structures for Claude Code conversation history.
//
// Claude Code stores conversations in ~/.claude/ with this layout:
//
//	~/.claude/
//	├── history.jsonl                          # Global prompt log (every input across all projects)
//	├── projects/
//	│   ├── <encoded-project-path>/
//	│   │   ├── sessions-index.json            # Session metadata: summaries, counts, branches
//	│   │   ├── <uuid>.jsonl                   # Full conversation transcript
//	│   │   ├── <uuid>/
//	│   │   │   ├── subagents/*.jsonl           # Subagent/Task tool transcripts
//	│   │   │   └── tool-results/               # Cached tool outputs
//	│   │   └── memory/
//	│   │       └── MEMORY.md                   # Auto-generated memory
package models

import (
	"path/filepath"
	"strings"
	"time"
)

// HistoryEntry represents a single line in ~/.claude/history.jsonl.
// This is the global prompt log — one entry per user input across all projects.
type HistoryEntry struct {
	SessionID   string    `json:"sessionId"`
	Prompt      string    `json:"prompt"`
	Timestamp   time.Time `json:"timestamp"`
	ProjectPath string    `json:"cwd"`
	Type        string    `json:"type,omitempty"`
}

// SessionIndex represents the contents of sessions-index.json.
// Maps session UUIDs to their metadata.
type SessionIndex map[string]SessionMeta

// SessionMeta holds metadata for a single session from sessions-index.json.
type SessionMeta struct {
	SessionID   string    `json:"sessionId"`
	Summary     string    `json:"summary"`
	MessageCount int      `json:"messageCount"`
	GitBranch   string    `json:"gitBranch,omitempty"`
	CreatedAt   time.Time `json:"createdAt"`
	UpdatedAt   time.Time `json:"updatedAt"`
	Model       string    `json:"model,omitempty"`
	LeafVersion string    `json:"leafVersion,omitempty"`
}

// TranscriptMessage represents a single message in a session .jsonl transcript.
type TranscriptMessage struct {
	ParentUUID  *string `json:"parentUuid"`
	IsSidechain bool    `json:"isSidechain"`
	SessionID   string  `json:"sessionId"`
	Version     string  `json:"version,omitempty"`
	AgentID     string  `json:"agentId,omitempty"`
	Type        string  `json:"type"` // "user", "assistant", "system"
	Message     Message `json:"message"`
	Timestamp   string  `json:"timestamp,omitempty"`
}

// Message holds the role and content of a transcript message.
type Message struct {
	Role    string      `json:"role"`
	Content interface{} `json:"content"` // string or []ContentBlock
}

// ContentBlock represents structured content (text, tool_use, tool_result, etc.)
type ContentBlock struct {
	Type  string      `json:"type"`
	Text  string      `json:"text,omitempty"`
	ID    string      `json:"id,omitempty"`
	Name  string      `json:"name,omitempty"`
	Input interface{} `json:"input,omitempty"`
}

// GetTextContent extracts plain text from a Message's content field,
// handling both string and []ContentBlock formats.
func (m *Message) GetTextContent() string {
	switch v := m.Content.(type) {
	case string:
		return v
	case []interface{}:
		var parts []string
		for _, item := range v {
			if block, ok := item.(map[string]interface{}); ok {
				if t, ok := block["text"].(string); ok {
					parts = append(parts, t)
				}
			}
		}
		return strings.Join(parts, "\n")
	}
	return ""
}

// Project represents a discovered Claude Code project with all its sessions.
type Project struct {
	EncodedPath string        `json:"encodedPath"`
	RealPath    string        `json:"realPath"`
	Name        string        `json:"name"`        // Just the directory name
	Sessions    []SessionMeta `json:"sessions"`
	DirPath     string        `json:"dirPath"`      // Full path to the project dir in ~/.claude/projects/
	HasMemory   bool          `json:"hasMemory"`
}

// Session is an enriched view combining metadata with transcript data.
type Session struct {
	SessionMeta
	ProjectName string              `json:"projectName"`
	ProjectPath string              `json:"projectPath"`
	Messages    []TranscriptMessage `json:"messages,omitempty"`
	UserPrompts []string            `json:"userPrompts,omitempty"` // Extracted user messages for quick scanning
}

// Catalog is the top-level structure: all projects and their sessions.
type Catalog struct {
	ClaudeDir   string    `json:"claudeDir"`
	ScannedAt   time.Time `json:"scannedAt"`
	Projects    []Project `json:"projects"`
	TotalSessions int    `json:"totalSessions"`
}

// DecodeProjectPath attempts to convert an encoded directory name back to a filesystem path.
// WARNING: This is ambiguous because dashes in directory names are indistinguishable from
// path separators. Use ResolveProjectPaths() with history.jsonl for accurate mapping.
// e.g., "-Users-gavin-Code-prism-tui" could be "/Users/gavin/Code/prism-tui" or
// "/Users/gavin/Code/prism/tui" — we can't tell from the encoding alone.
func DecodeProjectPath(encoded string) string {
	if encoded == "" {
		return ""
	}
	// Best-effort: replace leading dash with / and preserve the rest as-is.
	// This gives us the encoded form with a leading slash, which is at least
	// recognizable. Accurate paths require cross-referencing with history.jsonl.
	if strings.HasPrefix(encoded, "-") {
		return "/" + encoded[1:]
	}
	return encoded
}

// EncodeProjectPath converts a filesystem path to the encoded directory name.
// e.g., "/Users/gavin/Code/prism" -> "-Users-gavin-Code-prism"
func EncodeProjectPath(realPath string) string {
	return strings.ReplaceAll(realPath, string(filepath.Separator), "-")
}

// ProjectNameFromEncoded extracts a project name from the encoded path.
// Uses the last dash-separated segment(s) as a heuristic, or falls back to
// the full encoded name. For reliable names, use ResolveProjectPaths().
func ProjectNameFromEncoded(encoded string) string {
	// Strip leading dash
	s := strings.TrimPrefix(encoded, "-")
	parts := strings.Split(s, "-")
	if len(parts) == 0 {
		return encoded
	}
	// Return the last component — often the project name.
	// But this may be wrong for multi-word project names like "prism-tui".
	return parts[len(parts)-1]
}

// ProjectNameFromPath extracts the last component of a filesystem path.
func ProjectNameFromPath(path string) string {
	return filepath.Base(path)
}
