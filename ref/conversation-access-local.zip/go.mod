module github.com/spectrum-studio/cchistory

go 1.22
