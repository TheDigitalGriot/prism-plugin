#!/bin/bash
# Generate synthetic test data matching Claude Code's local storage format.
# Usage: ./generate_testdata.sh <output_dir>
set -e

OUT="${1:-./.test-claude}"
rm -rf "$OUT"

mkdir -p "$OUT/projects/-Users-gavin-Code-prism-tui"
mkdir -p "$OUT/projects/-Users-gavin-Code-prism-tui/a1b2c3d4-e5f6-7890-abcd-ef1234567890/subagents"
mkdir -p "$OUT/projects/-Users-gavin-Code-prism-tui/a1b2c3d4-e5f6-7890-abcd-ef1234567890/tool-results"
mkdir -p "$OUT/projects/-Users-gavin-Code-prism-tui/memory"

mkdir -p "$OUT/projects/-Users-gavin-Code-spectrum-cli"
mkdir -p "$OUT/projects/-Users-gavin-Code-charmforge"

# ─── history.jsonl ───
cat > "$OUT/history.jsonl" << 'HISTORY'
{"sessionId":"a1b2c3d4-e5f6-7890-abcd-ef1234567890","prompt":"implement the splash screen with icosahedron wireframe","timestamp":"2026-02-18T10:30:00Z","cwd":"/Users/gavin/Code/prism-tui","type":"user"}
{"sessionId":"a1b2c3d4-e5f6-7890-abcd-ef1234567890","prompt":"add terminal background color detection with OSC 11","timestamp":"2026-02-18T11:15:00Z","cwd":"/Users/gavin/Code/prism-tui","type":"user"}
{"sessionId":"b2c3d4e5-f6a7-8901-bcde-f12345678901","prompt":"migrate ralph namespace to spectrum","timestamp":"2026-02-17T09:00:00Z","cwd":"/Users/gavin/Code/spectrum-cli","type":"user"}
{"sessionId":"b2c3d4e5-f6a7-8901-bcde-f12345678901","prompt":"update stories.json path handling for .prism directory","timestamp":"2026-02-17T10:30:00Z","cwd":"/Users/gavin/Code/spectrum-cli","type":"user"}
{"sessionId":"c3d4e5f6-a7b8-9012-cdef-123456789012","prompt":"design the CharmForge component library panel","timestamp":"2026-02-16T14:00:00Z","cwd":"/Users/gavin/Code/charmforge","type":"user"}
{"sessionId":"d4e5f6a7-b8c9-0123-defa-234567890123","prompt":"set up Sidecar integration vertical slice","timestamp":"2026-02-15T16:00:00Z","cwd":"/Users/gavin/Code/prism-tui","type":"user"}
HISTORY

# ─── sessions-index.json for prism-tui ───
cat > "$OUT/projects/-Users-gavin-Code-prism-tui/sessions-index.json" << 'INDEX'
{
  "a1b2c3d4-e5f6-7890-abcd-ef1234567890": {
    "sessionId": "a1b2c3d4-e5f6-7890-abcd-ef1234567890",
    "summary": "Splash screen icosahedron wireframe and terminal bg detection",
    "messageCount": 24,
    "gitBranch": "feat/splash-screen",
    "createdAt": "2026-02-18T10:30:00Z",
    "updatedAt": "2026-02-18T12:45:00Z",
    "model": "claude-sonnet-4-5-20250514"
  },
  "d4e5f6a7-b8c9-0123-defa-234567890123": {
    "sessionId": "d4e5f6a7-b8c9-0123-defa-234567890123",
    "summary": "Sidecar integration: vertical slice decomposition and UI patterns",
    "messageCount": 42,
    "gitBranch": "feat/sidecar-integration",
    "createdAt": "2026-02-15T16:00:00Z",
    "updatedAt": "2026-02-15T20:30:00Z",
    "model": "claude-sonnet-4-5-20250514"
  }
}
INDEX

# ─── sessions-index.json for spectrum-cli ───
cat > "$OUT/projects/-Users-gavin-Code-spectrum-cli/sessions-index.json" << 'INDEX'
{
  "b2c3d4e5-f6a7-8901-bcde-f12345678901": {
    "sessionId": "b2c3d4e5-f6a7-8901-bcde-f12345678901",
    "summary": "Ralph to Spectrum namespace migration — path handling and .prism directory",
    "messageCount": 36,
    "gitBranch": "refactor/spectrum-namespace",
    "createdAt": "2026-02-17T09:00:00Z",
    "updatedAt": "2026-02-17T13:00:00Z",
    "model": "claude-sonnet-4-5-20250514"
  }
}
INDEX

# ─── sessions-index.json for charmforge ───
cat > "$OUT/projects/-Users-gavin-Code-charmforge/sessions-index.json" << 'INDEX'
{
  "c3d4e5f6-a7b8-9012-cdef-123456789012": {
    "sessionId": "c3d4e5f6-a7b8-9012-cdef-123456789012",
    "summary": "CharmForge PRD: component library, drag-drop interface, AI Copilot",
    "messageCount": 18,
    "gitBranch": "main",
    "createdAt": "2026-02-16T14:00:00Z",
    "updatedAt": "2026-02-16T16:30:00Z",
    "model": "claude-sonnet-4-5-20250514"
  }
}
INDEX

# ─── Sample transcript (prism-tui session) ───
cat > "$OUT/projects/-Users-gavin-Code-prism-tui/a1b2c3d4-e5f6-7890-abcd-ef1234567890.jsonl" << 'TRANSCRIPT'
{"parentUuid":null,"isSidechain":false,"sessionId":"a1b2c3d4-e5f6-7890-abcd-ef1234567890","version":"2.1.20","type":"user","message":{"role":"user","content":"implement the splash screen with icosahedron wireframe rendering using ASCII density characters"},"timestamp":"2026-02-18T10:30:00Z"}
{"parentUuid":null,"isSidechain":false,"sessionId":"a1b2c3d4-e5f6-7890-abcd-ef1234567890","version":"2.1.20","type":"assistant","message":{"role":"assistant","content":"I'll implement the splash screen with a proper 3D icosahedron wireframe. Let me start by defining the vertex and edge data for the icosahedron, then build the projection and ASCII rendering pipeline.\n\nFirst, let me look at the current splash screen code..."},"timestamp":"2026-02-18T10:30:15Z"}
{"parentUuid":null,"isSidechain":false,"sessionId":"a1b2c3d4-e5f6-7890-abcd-ef1234567890","version":"2.1.20","type":"user","message":{"role":"user","content":"add terminal background color detection with OSC 11 query, falling back to IDE settings file parsing"},"timestamp":"2026-02-18T11:15:00Z"}
{"parentUuid":null,"isSidechain":false,"sessionId":"a1b2c3d4-e5f6-7890-abcd-ef1234567890","version":"2.1.20","type":"assistant","message":{"role":"assistant","content":"I'll implement the background color detection with a robust fallback chain: OSC 11 → IDE config parsing → env vars → defaults. Let me structure this as a detector package..."},"timestamp":"2026-02-18T11:15:20Z"}
TRANSCRIPT

# ─── Sample subagent transcript ───
cat > "$OUT/projects/-Users-gavin-Code-prism-tui/a1b2c3d4-e5f6-7890-abcd-ef1234567890/subagents/sub-001.jsonl" << 'SUBAGENT'
{"parentUuid":null,"isSidechain":true,"sessionId":"a1b2c3d4-e5f6-7890-abcd-ef1234567890","version":"2.1.20","agentId":"a0a7cc0","type":"user","message":{"role":"user","content":"Search the codebase for existing color detection utilities"},"timestamp":"2026-02-18T11:16:00Z"}
{"parentUuid":null,"isSidechain":true,"sessionId":"a1b2c3d4-e5f6-7890-abcd-ef1234567890","version":"2.1.20","agentId":"a0a7cc0","type":"assistant","message":{"role":"assistant","content":"Found existing utilities in internal/theme/colors.go..."},"timestamp":"2026-02-18T11:16:10Z"}
SUBAGENT

# ─── MEMORY.md ───
cat > "$OUT/projects/-Users-gavin-Code-prism-tui/memory/MEMORY.md" << 'MEMORY'
# Prism TUI Memory

- Uses 4-color spectral palette: Blue #3B82F6, Teal #14B8A6, Green #22C55E, Amber #F59E0B
- Splash screen uses 3D icosahedron wireframe with ASCII density rendering
- Terminal bg detection: OSC 11 → IDE config → env vars → defaults
- Integration methodology: 6-layer approach, never write Layer 5 before Layers 1-3
MEMORY

echo "✅ Test data generated in $OUT"
echo ""
echo "Structure:"
find "$OUT" -type f | sort | sed "s|$OUT|~/.claude|"
