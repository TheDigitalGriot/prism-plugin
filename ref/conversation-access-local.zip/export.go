// Package export provides output formatters for Claude Code conversation data.
package export

import (
	"encoding/json"
	"fmt"
	"os"
	"strings"
	"time"

	"github.com/spectrum-studio/cchistory/internal/models"
)

// Format specifies the output format.
type Format string

const (
	FormatJSON     Format = "json"
	FormatMarkdown Format = "markdown"
	FormatPrism    Format = "prism" // Prism CLI-compatible output
)

// ExportCatalog writes a full catalog to the given path in the specified format.
func ExportCatalog(catalog *models.Catalog, path string, format Format) error {
	var data []byte
	var err error

	switch format {
	case FormatJSON:
		data, err = exportJSON(catalog)
	case FormatMarkdown:
		data, err = exportMarkdown(catalog)
	case FormatPrism:
		data, err = exportPrism(catalog)
	default:
		return fmt.Errorf("unknown format: %s", format)
	}

	if err != nil {
		return err
	}

	return os.WriteFile(path, data, 0644)
}

func exportJSON(catalog *models.Catalog) ([]byte, error) {
	return json.MarshalIndent(catalog, "", "  ")
}

func exportMarkdown(catalog *models.Catalog) ([]byte, error) {
	var b strings.Builder

	b.WriteString("# Claude Code Conversation Catalog\n\n")
	b.WriteString(fmt.Sprintf("**Scanned:** %s  \n", catalog.ScannedAt.Format(time.RFC1123)))
	b.WriteString(fmt.Sprintf("**Projects:** %d  \n", len(catalog.Projects)))
	b.WriteString(fmt.Sprintf("**Total Sessions:** %d  \n\n", catalog.TotalSessions))
	b.WriteString("---\n\n")

	for _, proj := range catalog.Projects {
		b.WriteString(fmt.Sprintf("## %s\n\n", proj.Name))
		b.WriteString(fmt.Sprintf("**Path:** `%s`  \n", proj.RealPath))
		b.WriteString(fmt.Sprintf("**Sessions:** %d  \n", len(proj.Sessions)))
		if proj.HasMemory {
			b.WriteString("**Memory:** ✓  \n")
		}
		b.WriteString("\n")

		if len(proj.Sessions) > 0 {
			b.WriteString("| # | Date | Summary | Messages | Branch |\n")
			b.WriteString("|---|------|---------|----------|--------|\n")
			for i, s := range proj.Sessions {
				summary := truncate(s.Summary, 60)
				date := s.UpdatedAt.Format("Jan 02 15:04")
				branch := s.GitBranch
				if branch == "" {
					branch = "-"
				}
				b.WriteString(fmt.Sprintf("| %d | %s | %s | %d | %s |\n",
					i+1, date, summary, s.MessageCount, branch))
			}
			b.WriteString("\n")
		}
	}

	return []byte(b.String()), nil
}

// PrismProject is the Prism CLI-compatible project format.
type PrismProject struct {
	ID          string         `json:"id"`
	Name        string         `json:"name"`
	Path        string         `json:"path"`
	Source      string         `json:"source"` // always "claude-code"
	HasMemory   bool           `json:"hasMemory"`
	Sessions    []PrismSession `json:"sessions"`
	LastActive  time.Time      `json:"lastActive"`
}

// PrismSession is the Prism CLI-compatible session format.
type PrismSession struct {
	ID           string    `json:"id"`
	Summary      string    `json:"summary"`
	MessageCount int       `json:"messageCount"`
	Branch       string    `json:"branch,omitempty"`
	CreatedAt    time.Time `json:"createdAt"`
	UpdatedAt    time.Time `json:"updatedAt"`
	Model        string    `json:"model,omitempty"`
	Prompts      []string  `json:"prompts,omitempty"` // First N user prompts for context
}

// PrismCatalog is the top-level Prism-compatible export.
type PrismCatalog struct {
	Version   string         `json:"version"`
	Source    string         `json:"source"`
	ExportedAt time.Time    `json:"exportedAt"`
	Projects  []PrismProject `json:"projects"`
}

func exportPrism(catalog *models.Catalog) ([]byte, error) {
	pc := PrismCatalog{
		Version:    "1.0.0",
		Source:     "claude-code",
		ExportedAt: catalog.ScannedAt,
	}

	for _, proj := range catalog.Projects {
		pp := PrismProject{
			ID:        proj.EncodedPath,
			Name:      proj.Name,
			Path:      proj.RealPath,
			Source:    "claude-code",
			HasMemory: proj.HasMemory,
		}

		for _, s := range proj.Sessions {
			ps := PrismSession{
				ID:           s.SessionID,
				Summary:      s.Summary,
				MessageCount: s.MessageCount,
				Branch:       s.GitBranch,
				CreatedAt:    s.CreatedAt,
				UpdatedAt:    s.UpdatedAt,
				Model:        s.Model,
			}
			pp.Sessions = append(pp.Sessions, ps)

			if s.UpdatedAt.After(pp.LastActive) {
				pp.LastActive = s.UpdatedAt
			}
		}

		pc.Projects = append(pc.Projects, pp)
	}

	return json.MarshalIndent(pc, "", "  ")
}

func truncate(s string, maxLen int) string {
	if len(s) <= maxLen {
		return s
	}
	return s[:maxLen-3] + "..."
}
