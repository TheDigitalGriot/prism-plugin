package parser

import (
	"strings"

	"github.com/spectrum-studio/cchistory/internal/models"
)

// BuildPathMap creates a mapping from encoded project directory names to real filesystem paths
// by scanning history.jsonl entries. This is the only reliable way to resolve the ambiguous
// dash-encoding used by Claude Code.
func BuildPathMap(entries []models.HistoryEntry) map[string]string {
	pathMap := make(map[string]string)
	for _, e := range entries {
		if e.ProjectPath == "" {
			continue
		}
		encoded := models.EncodeProjectPath(e.ProjectPath)
		pathMap[encoded] = e.ProjectPath
	}
	return pathMap
}

// ResolveProjectPaths enriches a list of projects with real filesystem paths
// by cross-referencing with history.jsonl entries.
func (s *Scanner) ResolveProjectPaths(projects []models.Project) []models.Project {
	entries, err := s.LoadHistory()
	if err != nil || len(entries) == 0 {
		return projects
	}

	pathMap := BuildPathMap(entries)

	for i := range projects {
		if realPath, ok := pathMap[projects[i].EncodedPath]; ok {
			projects[i].RealPath = realPath
			projects[i].Name = models.ProjectNameFromPath(realPath)
		}
	}

	return projects
}

// MatchEncodedPath checks if an encoded project path could match a given real path.
// Since encoding is lossy (dashes are ambiguous), we check if the encoded form
// of the real path matches.
func MatchEncodedPath(encoded, realPath string) bool {
	candidate := models.EncodeProjectPath(realPath)
	return strings.EqualFold(encoded, candidate)
}
