package parser_test

import (
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"testing"

	"github.com/spectrum-studio/cchistory/internal/models"
	"github.com/spectrum-studio/cchistory/internal/parser"
)

var testDir string

func TestMain(m *testing.M) {
	// Generate test data
	tmp, err := os.MkdirTemp("", "cchistory-test-*")
	if err != nil {
		panic(err)
	}
	testDir = filepath.Join(tmp, ".test-claude")

	// Find the generate script relative to the test file
	cmd := exec.Command("bash", "../../testdata/generate_testdata.sh", testDir)
	cmd.Stdout = os.Stderr
	cmd.Stderr = os.Stderr
	if err := cmd.Run(); err != nil {
		panic("failed to generate test data: " + err.Error())
	}

	code := m.Run()
	os.RemoveAll(tmp)
	os.Exit(code)
}

func TestDiscoverProjects(t *testing.T) {
	s := parser.NewScanner(testDir)
	projects, err := s.DiscoverProjects()
	if err != nil {
		t.Fatalf("DiscoverProjects failed: %v", err)
	}

	if len(projects) != 3 {
		t.Errorf("expected 3 projects, got %d", len(projects))
	}

	// Before history resolution, names are heuristic (last segment of encoded path)
	// After ScanFull with history, they'll be accurate
	for _, p := range projects {
		if p.EncodedPath == "" {
			t.Error("project has empty encoded path")
		}
	}
}

func TestDecodeProjectPath(t *testing.T) {
	tests := []struct {
		encoded string
		want    string
	}{
		// DecodeProjectPath is best-effort — it can't distinguish path dashes from literal dashes
		{"-Users-gavin-Code-prism-tui", "/-Users-gavin-Code-prism-tui"},
		{"", ""},
	}

	for _, tt := range tests {
		got := models.DecodeProjectPath(tt.encoded)
		// Just verify it starts with / and isn't empty for non-empty input
		if tt.encoded != "" && !strings.HasPrefix(got, "/") {
			t.Errorf("DecodeProjectPath(%q) = %q, expected leading /", tt.encoded, got)
		}
		if tt.encoded == "" && got != "" {
			t.Errorf("DecodeProjectPath(%q) = %q, want empty", tt.encoded, got)
		}
	}
}

func TestLoadHistory(t *testing.T) {
	s := parser.NewScanner(testDir)
	entries, err := s.LoadHistory()
	if err != nil {
		t.Fatalf("LoadHistory failed: %v", err)
	}

	if len(entries) != 6 {
		t.Errorf("expected 6 history entries, got %d", len(entries))
	}

	// Should be sorted newest first
	if len(entries) >= 2 {
		if entries[0].Timestamp.Before(entries[1].Timestamp) {
			t.Error("history entries not sorted newest-first")
		}
	}
}

func TestGroupHistoryByProject(t *testing.T) {
	s := parser.NewScanner(testDir)
	entries, _ := s.LoadHistory()
	groups := parser.GroupHistoryByProject(entries)

	if len(groups) != 3 {
		t.Errorf("expected 3 project groups, got %d", len(groups))
	}

	prismEntries := groups["/Users/gavin/Code/prism-tui"]
	if len(prismEntries) != 3 {
		t.Errorf("expected 3 prism-tui entries, got %d", len(prismEntries))
	}
}

func TestLoadSessionIndex(t *testing.T) {
	s := parser.NewScanner(testDir)
	projectDir := filepath.Join(testDir, "projects", "-Users-gavin-Code-prism-tui")
	sessions, err := s.LoadSessionIndex(projectDir)
	if err != nil {
		t.Fatalf("LoadSessionIndex failed: %v", err)
	}

	if len(sessions) != 2 {
		t.Errorf("expected 2 sessions, got %d", len(sessions))
	}

	// Check that summaries were parsed
	found := false
	for _, sess := range sessions {
		if sess.Summary == "Splash screen icosahedron wireframe and terminal bg detection" {
			found = true
			if sess.MessageCount != 24 {
				t.Errorf("expected 24 messages, got %d", sess.MessageCount)
			}
			if sess.GitBranch != "feat/splash-screen" {
				t.Errorf("expected branch feat/splash-screen, got %s", sess.GitBranch)
			}
		}
	}
	if !found {
		t.Error("splash screen session not found")
	}
}

func TestLoadTranscript(t *testing.T) {
	s := parser.NewScanner(testDir)
	projectDir := filepath.Join(testDir, "projects", "-Users-gavin-Code-prism-tui")
	msgs, err := s.LoadSessionTranscript(projectDir, "a1b2c3d4-e5f6-7890-abcd-ef1234567890")
	if err != nil {
		t.Fatalf("LoadSessionTranscript failed: %v", err)
	}

	if len(msgs) != 4 {
		t.Errorf("expected 4 messages, got %d", len(msgs))
	}

	// Check message content extraction
	prompts := parser.ExtractUserPrompts(msgs)
	if len(prompts) != 2 {
		t.Errorf("expected 2 user prompts, got %d", len(prompts))
	}
}

func TestLoadSubagentTranscripts(t *testing.T) {
	s := parser.NewScanner(testDir)
	projectDir := filepath.Join(testDir, "projects", "-Users-gavin-Code-prism-tui")
	subs, err := s.LoadSubagentTranscripts(projectDir, "a1b2c3d4-e5f6-7890-abcd-ef1234567890")
	if err != nil {
		t.Fatalf("LoadSubagentTranscripts failed: %v", err)
	}

	if len(subs) != 1 {
		t.Errorf("expected 1 subagent transcript, got %d", len(subs))
	}

	if msgs, ok := subs["sub-001"]; ok {
		if len(msgs) != 2 {
			t.Errorf("expected 2 subagent messages, got %d", len(msgs))
		}
		if !msgs[0].IsSidechain {
			t.Error("subagent message should have isSidechain=true")
		}
	} else {
		t.Error("sub-001 transcript not found")
	}
}

func TestFilterProjectsByName(t *testing.T) {
	projects := []models.Project{
		{Name: "prism-tui", RealPath: "/Users/gavin/Code/prism-tui"},
		{Name: "spectrum-cli", RealPath: "/Users/gavin/Code/spectrum-cli"},
		{Name: "charmforge", RealPath: "/Users/gavin/Code/charmforge"},
	}

	matches := parser.FilterProjectsByName(projects, "prism")
	if len(matches) != 1 || matches[0].Name != "prism-tui" {
		t.Errorf("expected 1 match for 'prism', got %d", len(matches))
	}

	matches = parser.FilterProjectsByName(projects, "gavin")
	if len(matches) != 3 {
		t.Errorf("expected 3 matches for 'gavin' (in path), got %d", len(matches))
	}
}

func TestProjectHasMemory(t *testing.T) {
	s := parser.NewScanner(testDir)
	catalog, _ := s.ScanFull() // ScanFull resolves names via history

	for _, p := range catalog.Projects {
		if p.Name == "prism-tui" && !p.HasMemory {
			t.Error("prism-tui should have memory")
		}
		if p.Name == "spectrum-cli" && p.HasMemory {
			t.Error("spectrum-cli should not have memory")
		}
	}
}

func TestScanFull(t *testing.T) {
	s := parser.NewScanner(testDir)
	catalog, err := s.ScanFull()
	if err != nil {
		t.Fatalf("ScanFull failed: %v", err)
	}

	if catalog.TotalSessions != 4 {
		t.Errorf("expected 4 total sessions, got %d", catalog.TotalSessions)
	}
	if len(catalog.Projects) != 3 {
		t.Errorf("expected 3 projects, got %d", len(catalog.Projects))
	}

	// After ScanFull, paths should be resolved from history.jsonl
	names := make(map[string]bool)
	for _, p := range catalog.Projects {
		names[p.Name] = true
	}
	for _, expected := range []string{"prism-tui", "spectrum-cli", "charmforge"} {
		if !names[expected] {
			t.Errorf("after resolution, missing expected project name: %s (have: %v)", expected, names)
		}
	}
}

func TestResolveProjectPaths(t *testing.T) {
	s := parser.NewScanner(testDir)
	projects, _ := s.DiscoverProjects()

	// Before resolution, names are heuristic
	resolved := s.ResolveProjectPaths(projects)

	for _, p := range resolved {
		if p.EncodedPath == "-Users-gavin-Code-prism-tui" {
			if p.RealPath != "/Users/gavin/Code/prism-tui" {
				t.Errorf("expected resolved path /Users/gavin/Code/prism-tui, got %s", p.RealPath)
			}
			if p.Name != "prism-tui" {
				t.Errorf("expected resolved name prism-tui, got %s", p.Name)
			}
		}
	}
}
