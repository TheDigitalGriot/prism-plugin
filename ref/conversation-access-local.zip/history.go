package parser

import (
	"bufio"
	"encoding/json"
	"fmt"
	"os"
	"sort"
	"strings"

	"github.com/spectrum-studio/cchistory/internal/models"
)

// LoadHistory reads and parses ~/.claude/history.jsonl.
// Returns entries sorted newest-first.
func (s *Scanner) LoadHistory() ([]models.HistoryEntry, error) {
	return LoadHistoryFile(s.HistoryFile())
}

// LoadHistoryFile reads a history.jsonl from the given path.
func LoadHistoryFile(path string) ([]models.HistoryEntry, error) {
	f, err := os.Open(path)
	if err != nil {
		if os.IsNotExist(err) {
			return nil, nil
		}
		return nil, fmt.Errorf("cannot open history file: %w", err)
	}
	defer f.Close()

	var entries []models.HistoryEntry
	scanner := bufio.NewScanner(f)
	// Increase buffer for potentially large lines
	scanner.Buffer(make([]byte, 0, 256*1024), 1024*1024)

	lineNum := 0
	for scanner.Scan() {
		lineNum++
		line := strings.TrimSpace(scanner.Text())
		if line == "" {
			continue
		}

		var entry models.HistoryEntry
		if err := json.Unmarshal([]byte(line), &entry); err != nil {
			// Skip malformed lines rather than failing entirely
			continue
		}
		entries = append(entries, entry)
	}

	if err := scanner.Err(); err != nil {
		return entries, fmt.Errorf("error reading history file: %w", err)
	}

	// Sort newest first
	sort.Slice(entries, func(i, j int) bool {
		return entries[i].Timestamp.After(entries[j].Timestamp)
	})

	return entries, nil
}

// GroupHistoryByProject groups history entries by their project path.
func GroupHistoryByProject(entries []models.HistoryEntry) map[string][]models.HistoryEntry {
	groups := make(map[string][]models.HistoryEntry)
	for _, e := range entries {
		key := e.ProjectPath
		if key == "" {
			key = "(no project)"
		}
		groups[key] = append(groups[key], e)
	}
	return groups
}

// GroupHistoryBySession groups history entries by session ID.
func GroupHistoryBySession(entries []models.HistoryEntry) map[string][]models.HistoryEntry {
	groups := make(map[string][]models.HistoryEntry)
	for _, e := range entries {
		key := e.SessionID
		if key == "" {
			key = "(no session)"
		}
		groups[key] = append(groups[key], e)
	}
	return groups
}
