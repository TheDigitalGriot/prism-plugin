package parser

import (
	"bufio"
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"strings"

	"github.com/spectrum-studio/cchistory/internal/models"
)

// LoadTranscript reads a session transcript .jsonl file and returns all messages.
func LoadTranscript(path string) ([]models.TranscriptMessage, error) {
	f, err := os.Open(path)
	if err != nil {
		return nil, fmt.Errorf("cannot open transcript: %w", err)
	}
	defer f.Close()

	var messages []models.TranscriptMessage
	scanner := bufio.NewScanner(f)
	scanner.Buffer(make([]byte, 0, 256*1024), 2*1024*1024)

	for scanner.Scan() {
		line := strings.TrimSpace(scanner.Text())
		if line == "" {
			continue
		}

		var msg models.TranscriptMessage
		if err := json.Unmarshal([]byte(line), &msg); err != nil {
			continue // skip malformed lines
		}
		messages = append(messages, msg)
	}

	if err := scanner.Err(); err != nil {
		return messages, fmt.Errorf("error reading transcript: %w", err)
	}

	return messages, nil
}

// LoadSessionTranscript loads the main transcript for a session in a project directory.
// It looks for <sessionID>.jsonl in the project dir.
func (s *Scanner) LoadSessionTranscript(projectDir, sessionID string) ([]models.TranscriptMessage, error) {
	// Try the direct .jsonl file first
	path := filepath.Join(projectDir, sessionID+".jsonl")
	if _, err := os.Stat(path); err == nil {
		return LoadTranscript(path)
	}

	// Try main.jsonl inside a session subdirectory
	path = filepath.Join(projectDir, sessionID, "main.jsonl")
	if _, err := os.Stat(path); err == nil {
		return LoadTranscript(path)
	}

	return nil, fmt.Errorf("no transcript found for session %s", sessionID)
}

// LoadSubagentTranscripts loads all subagent/sidechain transcripts for a session.
func (s *Scanner) LoadSubagentTranscripts(projectDir, sessionID string) (map[string][]models.TranscriptMessage, error) {
	subagentDir := filepath.Join(projectDir, sessionID, "subagents")
	entries, err := os.ReadDir(subagentDir)
	if err != nil {
		if os.IsNotExist(err) {
			return nil, nil
		}
		return nil, fmt.Errorf("cannot read subagents directory: %w", err)
	}

	results := make(map[string][]models.TranscriptMessage)
	for _, entry := range entries {
		if entry.IsDir() || !strings.HasSuffix(entry.Name(), ".jsonl") {
			continue
		}
		name := strings.TrimSuffix(entry.Name(), ".jsonl")
		msgs, err := LoadTranscript(filepath.Join(subagentDir, entry.Name()))
		if err != nil {
			continue
		}
		results[name] = msgs
	}

	return results, nil
}

// ExtractUserPrompts pulls out just the user messages from a transcript for quick scanning.
func ExtractUserPrompts(messages []models.TranscriptMessage) []string {
	var prompts []string
	for _, msg := range messages {
		if msg.Type == "user" || msg.Message.Role == "user" {
			text := msg.Message.GetTextContent()
			if text != "" {
				prompts = append(prompts, text)
			}
		}
	}
	return prompts
}

// BuildEnrichedSession combines session metadata with transcript data.
func (s *Scanner) BuildEnrichedSession(project models.Project, meta models.SessionMeta) models.Session {
	session := models.Session{
		SessionMeta: meta,
		ProjectName: project.Name,
		ProjectPath: project.RealPath,
	}

	msgs, err := s.LoadSessionTranscript(project.DirPath, meta.SessionID)
	if err == nil {
		session.Messages = msgs
		session.UserPrompts = ExtractUserPrompts(msgs)
	}

	return session
}

// FindTranscriptFiles finds all .jsonl files in a project directory (top-level only).
func FindTranscriptFiles(projectDir string) ([]string, error) {
	entries, err := os.ReadDir(projectDir)
	if err != nil {
		return nil, err
	}

	var files []string
	for _, entry := range entries {
		if !entry.IsDir() && strings.HasSuffix(entry.Name(), ".jsonl") {
			files = append(files, filepath.Join(projectDir, entry.Name()))
		}
	}
	return files, nil
}
