// Package parser handles reading and parsing Claude Code's local storage files.
package parser

import (
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"sort"
	"strings"
	"time"

	"github.com/spectrum-studio/cchistory/internal/models"
)

// DefaultClaudeDir returns the default ~/.claude directory path.
func DefaultClaudeDir() (string, error) {
	home, err := os.UserHomeDir()
	if err != nil {
		return "", fmt.Errorf("cannot determine home directory: %w", err)
	}
	return filepath.Join(home, ".claude"), nil
}

// Scanner reads and catalogs Claude Code conversation data.
type Scanner struct {
	ClaudeDir string
}

// NewScanner creates a Scanner pointing at the given ~/.claude directory.
func NewScanner(claudeDir string) *Scanner {
	return &Scanner{ClaudeDir: claudeDir}
}

// NewDefaultScanner creates a Scanner using the default ~/.claude location.
func NewDefaultScanner() (*Scanner, error) {
	dir, err := DefaultClaudeDir()
	if err != nil {
		return nil, err
	}
	return NewScanner(dir), nil
}

// ProjectsDir returns the path to ~/.claude/projects/
func (s *Scanner) ProjectsDir() string {
	return filepath.Join(s.ClaudeDir, "projects")
}

// HistoryFile returns the path to ~/.claude/history.jsonl
func (s *Scanner) HistoryFile() string {
	return filepath.Join(s.ClaudeDir, "history.jsonl")
}

// DiscoverProjects finds all project directories under ~/.claude/projects/
func (s *Scanner) DiscoverProjects() ([]models.Project, error) {
	projectsDir := s.ProjectsDir()
	entries, err := os.ReadDir(projectsDir)
	if err != nil {
		if os.IsNotExist(err) {
			return nil, nil
		}
		return nil, fmt.Errorf("cannot read projects directory: %w", err)
	}

	var projects []models.Project
	for _, entry := range entries {
		if !entry.IsDir() {
			continue
		}

		encoded := entry.Name()
		dirPath := filepath.Join(projectsDir, encoded)

		proj := models.Project{
			EncodedPath: encoded,
			RealPath:    models.DecodeProjectPath(encoded),       // best-effort, resolved later via history
			Name:        models.ProjectNameFromEncoded(encoded),   // heuristic, resolved later via history
			DirPath:     dirPath,
			HasMemory:   fileExists(filepath.Join(dirPath, "memory", "MEMORY.md")),
		}

		// Load session index if available
		sessions, err := s.LoadSessionIndex(dirPath)
		if err == nil {
			proj.Sessions = sessions
		}

		projects = append(projects, proj)
	}

	// Sort by most recently updated session
	sort.Slice(projects, func(i, j int) bool {
		iTime := latestSession(projects[i].Sessions)
		jTime := latestSession(projects[j].Sessions)
		return iTime.After(jTime)
	})

	return projects, nil
}

// LoadSessionIndex reads and parses sessions-index.json from a project directory.
func (s *Scanner) LoadSessionIndex(projectDir string) ([]models.SessionMeta, error) {
	indexPath := filepath.Join(projectDir, "sessions-index.json")
	data, err := os.ReadFile(indexPath)
	if err != nil {
		return nil, fmt.Errorf("cannot read sessions index: %w", err)
	}

	var index models.SessionIndex
	if err := json.Unmarshal(data, &index); err != nil {
		// Try parsing as an array instead (some versions use different formats)
		var sessions []models.SessionMeta
		if err2 := json.Unmarshal(data, &sessions); err2 != nil {
			return nil, fmt.Errorf("cannot parse sessions index: %w (also tried array: %w)", err, err2)
		}
		return sessions, nil
	}

	// Convert map to sorted slice
	var sessions []models.SessionMeta
	for id, meta := range index {
		if meta.SessionID == "" {
			meta.SessionID = id
		}
		sessions = append(sessions, meta)
	}

	// Sort newest first
	sort.Slice(sessions, func(i, j int) bool {
		return sessions[i].UpdatedAt.After(sessions[j].UpdatedAt)
	})

	return sessions, nil
}

// ScanFull performs a complete scan: discovers projects, loads all session metadata,
// resolves real paths from history.jsonl, and returns a full Catalog.
func (s *Scanner) ScanFull() (*models.Catalog, error) {
	projects, err := s.DiscoverProjects()
	if err != nil {
		return nil, err
	}

	// Resolve ambiguous paths using history.jsonl cross-reference
	projects = s.ResolveProjectPaths(projects)

	totalSessions := 0
	for _, p := range projects {
		totalSessions += len(p.Sessions)
	}

	return &models.Catalog{
		ClaudeDir:     s.ClaudeDir,
		ScannedAt:     now(),
		Projects:      projects,
		TotalSessions: totalSessions,
	}, nil
}

// FilterProjectsByName returns projects whose name contains the given substring (case-insensitive).
func FilterProjectsByName(projects []models.Project, query string) []models.Project {
	query = strings.ToLower(query)
	var matches []models.Project
	for _, p := range projects {
		if strings.Contains(strings.ToLower(p.Name), query) ||
			strings.Contains(strings.ToLower(p.RealPath), query) {
			matches = append(matches, p)
		}
	}
	return matches
}

func fileExists(path string) bool {
	_, err := os.Stat(path)
	return err == nil
}

func latestSession(sessions []models.SessionMeta) (latest time.Time) {
	for _, s := range sessions {
		if s.UpdatedAt.After(latest) {
			latest = s.UpdatedAt
		}
	}
	return
}

func now() time.Time {
	return time.Now()
}
